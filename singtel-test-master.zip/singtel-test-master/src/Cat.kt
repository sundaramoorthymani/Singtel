class Cat: Animal(true, true, true, false) {
    override fun sing() {
        println("Meow")
    }
}
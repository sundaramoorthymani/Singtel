class Duck: Bird(true, true, true, true) {

    override fun sing() {
        println("Quack, quack")
    }
}
package enums

enum class SIZE {
    LARGE,
    SMALL
}
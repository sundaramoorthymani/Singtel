package enums

enum class STAGE {
    CATERPILLAR,
    BUTTERFLY
}
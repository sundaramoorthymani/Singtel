package enums

enum class COLOUR {
    GREY,
    ORANGE
}